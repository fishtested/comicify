document.body.style.fontFamily = "Comic Sans MS, sans-serif";
